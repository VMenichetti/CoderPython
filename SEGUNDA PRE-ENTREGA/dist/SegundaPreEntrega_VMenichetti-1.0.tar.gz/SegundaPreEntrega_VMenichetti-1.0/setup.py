from setuptools import setup, find_packages

setup (
    name = "SegundaPreEntrega_VMenichetti",
    version = "1.0",
    description = "Segunda Pre-entrega PYTHON - CODERHOUSE",
    author = "Verónica Menichetti",
    author_email = "ingvmenichetti@gmail.com",

    packages = ["SegundaPreEntrega_VMenichetti"]    
)